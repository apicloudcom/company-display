
class Config{
    constructor(){
    }
}

Config.restUrl = 'https://a6047375483366-dev.apicloud-saas.com/api';
Config.getbannersList = '/banners/list'; //获取轮播图列表
Config.getbannersInfo = '/banners/detail'; //获取轮播图详情
Config.getProjectConfigssInfo = '/project_configs/detail'; //获取系统配置
Config.getCasesList = '/cases/list'; //获取案例列表
Config.getCasesInfo = '/cases/detail'; //获取案例详情
Config.getCasesList = '/cases/list'; //获取案例列表
Config.getFranchiseList = '/franchise_agent_contents/list'; //获取加盟代理内容列表
Config.getFranchiseDetail = '/franchise_agent_contents/detail'; //获取加盟代理内容详情
Config.postFranchiseAgentApplies = '/franchise_agent_applies/add'; //提交加盟请求

export {Config}; 